BLYNK RUSSIA FORUM BACKEND STARTER

This is a backend-enabled starter project. It is not yet deployed; no public URL exists until hosted.


LOCAL RUN (Node.js 18+):
1. Install Node.js.
2. Copy .env.example to .env and choose a long unique FOUNDER_PASSWORD and SESSION_SECRET.
3. In a terminal in this folder: npm install
4. Set environment variables from .env (on Windows PowerShell, use $env:FOUNDER_PASSWORD=... etc).
5. Run: npm start
6. Open http://localhost:3000

API:
POST /api/register {nickname,password}
POST /api/login {nickname,password}
POST /api/logout
GET /api/me
GET /api/topics
POST /api/topics (login required) {title,body,category}
GET /api/topics/:id/posts
POST /api/topics/:id/posts (login required) {body}
DELETE /api/topics/:id (moderator/admin/founder)

Founder is only created if FOUNDER_PASSWORD is set at first startup. If the DB was already created,
remove forum.sqlite only before any real user data exists, then restart with environment configured.
Use HTTPS and a persistent disk for SQLite on a production host. This project is a starter and needs
hosting configuration and UI integration for full forum workflows.
